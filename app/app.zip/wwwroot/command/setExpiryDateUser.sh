# $1 => date , $2 username 
sudo chage -E  $1 $2