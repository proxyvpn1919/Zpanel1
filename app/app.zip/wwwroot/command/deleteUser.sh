killall -u $1
deluser $1